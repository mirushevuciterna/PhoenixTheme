<?php

// Case: Get Involved
if( get_row_layout() == 'get_involved' ):

?>

<div class="containeri">
    <div class="container-fluid">
        <div class="content hideMe">
            <h1>We need your help. Get involved!</h1>
            <p>Lorem ipsum dolor sit amet dictum sit amet justo donec enim diam vulputate.</br> Vitae suscipit tellus mauris a diam
                maecenas sed enim ut habitasse platea dictumst.</p>
            <button type="button" class="btn btn-lg">Puchase Ekko</button>
        </div>
    </div>
</div>

<?php endif; ?>