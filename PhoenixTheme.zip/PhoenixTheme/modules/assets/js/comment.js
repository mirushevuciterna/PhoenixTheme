$(".comment-form-cookies-consent > label").text("Save my data for next time :)");




